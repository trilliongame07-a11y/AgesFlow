/*
  AegisFlow junction node  (ESP32, Arduino framework)
  Libraries (Library Manager): PubSubClient (Nick O'Leary), ArduinoJson (v7)

  Wiring (ESP32 DevKit):
    NS signal  R=13  Y=12  G=14      EW signal  R=27  Y=26  G=25   (LED + 220 ohm each)
    Ultrasonic NS  TRIG=5  ECHO=18   (HC-SR04, ECHO via 1k/2k divider to 3.3 V)
    Ultrasonic EW  TRIG=19 ECHO=21
    IR obstacle sensor (junction box) OUT=34   (LOW = something inside the junction)
    Buzzer = 23
  Flash one board per junction: change JUNCTION_ID (J1..J9).
*/
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

// ---------- CONFIG ----------
const char* WIFI_SSID   = "YOUR_WIFI";
const char* WIFI_PASS   = "YOUR_PASSWORD";
const char* MQTT_HOST   = "broker.hivemq.com";   // or your PC's IP running Mosquitto
const int   MQTT_PORT   = 1883;
const char* MQTT_PREFIX = "aegisflow-CHANGE-ME"; // must match backend/.env MQTT_PREFIX
const char* JUNCTION_ID = "J1";
const int   MAX_QUEUE_CM = 40;                   // sensor sees nothing beyond this = empty
// ----------------------------

const int NS_R=13, NS_Y=12, NS_G=14, EW_R=27, EW_Y=26, EW_G=25;
const int TRIG_NS=5, ECHO_NS=18, TRIG_EW=19, ECHO_EW=21, IR_BOX=34, BUZZ=23;
const unsigned long NORMAL_GREEN_MS=8000, YELLOW_MS=2000, ALLRED_MS=1000;

enum Phase { NS_GREEN, NS_YELLOW, ALLRED_TO_EW, EW_GREEN, EW_YELLOW, ALLRED_TO_NS };
Phase phase = NS_GREEN;
unsigned long phaseStart = 0;

bool cmdActive = false, cmdAlert = false;
char cmdApproach[3] = "NS";
unsigned long cmdUntil = 0;

WiFiClient net;
PubSubClient mqtt(net);
String topicSensors, topicCmd;
unsigned long lastPub = 0, lastBeep = 0;

void setLight(int r, int y, int g, int state) {          // 0=red 1=yellow 2=green
  digitalWrite(r, state == 0); digitalWrite(y, state == 1); digitalWrite(g, state == 2);
}
void show(int ns, int ew) { setLight(NS_R, NS_Y, NS_G, ns); setLight(EW_R, EW_Y, EW_G, ew); }
void gotoPhase(Phase p) { phase = p; phaseStart = millis(); }

int readQueue(int trig, int echo) {                      // 0..10 vehicles (model scale)
  digitalWrite(trig, LOW); delayMicroseconds(2);
  digitalWrite(trig, HIGH); delayMicroseconds(10); digitalWrite(trig, LOW);
  long us = pulseIn(echo, HIGH, 25000);
  if (us == 0) return 0;
  float cm = us * 0.0343 / 2.0;
  if (cm >= MAX_QUEUE_CM) return 0;
  return constrain((int)((MAX_QUEUE_CM - cm) / MAX_QUEUE_CM * 10.0 + 0.5), 0, 10);
}

void updateSignals() {
  unsigned long now = millis();
  if (cmdActive && (long)(now - cmdUntil) >= 0) cmdActive = false;   // failsafe -> normal cycle
  bool wantNS = cmdActive && strcmp(cmdApproach, "NS") == 0;
  bool wantEW = cmdActive && strcmp(cmdApproach, "EW") == 0;
  unsigned long el = now - phaseStart;
  switch (phase) {
    case NS_GREEN:     show(2, 0);
      if (wantEW || (!cmdActive && el >= NORMAL_GREEN_MS)) gotoPhase(NS_YELLOW); break;
    case NS_YELLOW:    show(1, 0); if (el >= YELLOW_MS) gotoPhase(ALLRED_TO_EW); break;
    case ALLRED_TO_EW: show(0, 0); if (el >= ALLRED_MS)  gotoPhase(EW_GREEN);    break;
    case EW_GREEN:     show(0, 2);
      if (wantNS || (!cmdActive && el >= NORMAL_GREEN_MS)) gotoPhase(EW_YELLOW); break;
    case EW_YELLOW:    show(0, 1); if (el >= YELLOW_MS) gotoPhase(ALLRED_TO_NS); break;
    case ALLRED_TO_NS: show(0, 0); if (el >= ALLRED_MS)  gotoPhase(NS_GREEN);    break;
  }
  if (cmdActive && cmdAlert && now - lastBeep > 400) {                // junction box blocked
    lastBeep = now; digitalWrite(BUZZ, !digitalRead(BUZZ));
  } else if (!(cmdActive && cmdAlert)) digitalWrite(BUZZ, LOW);
}

void onMessage(char* topic, byte* payload, unsigned int len) {
  JsonDocument d;
  if (deserializeJson(d, payload, len)) return;
  const char* mode = d["mode"] | "NORMAL";
  if (strcmp(mode, "NORMAL") == 0) { cmdActive = false; return; }
  strlcpy(cmdApproach, d["approach"] | "NS", sizeof(cmdApproach));
  cmdUntil = millis() + (unsigned long)(d["ttl_s"] | 5) * 1000UL;     // relative TTL: no clock sync needed
  cmdAlert = d["alert"] | false;
  cmdActive = true;
}

void ensureConnections() {
  if (WiFi.status() != WL_CONNECTED) { WiFi.begin(WIFI_SSID, WIFI_PASS); return; }
  if (!mqtt.connected()) {
    String id = String("aegis-") + JUNCTION_ID + "-" + String((uint32_t)ESP.getEfuseMac(), HEX);
    if (mqtt.connect(id.c_str())) mqtt.subscribe(topicCmd.c_str());
  }
}

void setup() {
  Serial.begin(115200);
  int outs[] = {NS_R,NS_Y,NS_G,EW_R,EW_Y,EW_G,TRIG_NS,TRIG_EW,BUZZ};
  for (int p : outs) pinMode(p, OUTPUT);
  pinMode(ECHO_NS, INPUT); pinMode(ECHO_EW, INPUT); pinMode(IR_BOX, INPUT);
  topicSensors = String(MQTT_PREFIX) + "/junction/" + JUNCTION_ID + "/sensors";
  topicCmd     = String(MQTT_PREFIX) + "/junction/" + JUNCTION_ID + "/cmd";
  mqtt.setServer(MQTT_HOST, MQTT_PORT); mqtt.setCallback(onMessage);
  WiFi.mode(WIFI_STA); WiFi.begin(WIFI_SSID, WIFI_PASS);
  gotoPhase(NS_GREEN);
}

void loop() {
  static unsigned long lastTry = 0;
  if (millis() - lastTry > 3000 && (WiFi.status() != WL_CONNECTED || !mqtt.connected())) { lastTry = millis(); ensureConnections(); }
  mqtt.loop();
  updateSignals();                                   // runs even when offline (resilience)
  if (millis() - lastPub >= 1000) {
    lastPub = millis();
    if (mqtt.connected()) {
      JsonDocument d;
      d["q_ns"] = readQueue(TRIG_NS, ECHO_NS);
      d["q_ew"] = readQueue(TRIG_EW, ECHO_EW);
      d["box_clear"] = digitalRead(IR_BOX) == HIGH;
      char buf[128]; size_t n = serializeJson(d, buf);
      mqtt.publish(topicSensors.c_str(), (const uint8_t*)buf, n);
    }
  }
}
