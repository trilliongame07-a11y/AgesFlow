# AegisFlow - runnable prototype (software + ESP32 hardware + Supabase)

```
ESP32 junction nodes --MQTT--> FastAPI backend (engine) --> Supabase (Postgres)
   (sensors, LEDs)  <--MQTT--   predict / orchestrate / verify / recover     |
                                        ^                                    v
        simulator.py (virtual city) ----+----> dashboard (http://127.0.0.1:8000)
```

## 1. Run the software demo (5 minutes, no hardware, no Supabase needed)
```bash
cd backend
python -m venv .venv
.venv\Scripts\activate          # Windows   |  source .venv/bin/activate   (Mac/Linux)
pip install -r requirements.txt
copy .env.example .env          # (cp on Mac/Linux). Leave MQTT_HOST and Supabase values empty for offline mode
uvicorn main:app --reload --port 8000
```
Open **http://127.0.0.1:8000** (live dashboard). In a second terminal:
```bash
python simulator.py                 # AegisFlow ON
python simulator.py --baseline      # plain fixed-time signals (compare travel time + stops)
python simulator.py --block J6      # junction J6 (on the default route) blocked -> safety alert + extended clearance
```
In VS Code you can also use **Run and Debug** (launch configs are included).

## 2. Supabase setup
1. Create a project at supabase.com.
2. **SQL Editor -> New query**: paste `supabase/schema.sql` -> Run.
3. **Project Settings -> API**: copy the *Project URL* and the **service_role** key into `backend/.env`
   (`SUPABASE_URL`, `SUPABASE_SERVICE_KEY`). Keep the service key on the backend only - never in the browser.
4. Restart uvicorn; you should see `[db] Supabase connected`. Run the simulator, then check the tables
   `corridor_events`, `emergency_requests`, `sensor_readings`, `signal_commands` and the view `corridor_kpis`.

Vehicle credentials live in `vehicles` (key stored as SHA-256). To add one:
```sql
insert into vehicles (id, priority, api_key_hash)
values ('AMB-02', 0, encode(digest('my-secret-key','sha256'),'hex'));
```

## 3. Hardware (ESP32)
1. Install Arduino IDE (or PlatformIO), ESP32 board package, libraries **PubSubClient** and **ArduinoJson v7**.
2. Open `firmware/junction_node/junction_node.ino`; set Wi-Fi, `MQTT_PREFIX` (same value as `.env`), and `JUNCTION_ID`.
3. Set `MQTT_HOST=broker.hivemq.com` in `backend/.env` (or run Mosquitto on your PC and use its IP in both places).
4. Flash. Junction nodes publish queue levels + junction-box state every second and obey commands; if the backend or Wi-Fi
   dies, commands expire in a few seconds and the node returns to its normal timing (fail-safe).
5. Real ambulance: any device (ESP32 + RFID/GPS, phone) can POST to the API:
```bash
curl -X POST http://PC_IP:8000/api/request -H "Content-Type: application/json" -H "X-Vehicle-Key: demo-key-123" \
     -d '{"vehicle_id":"AMB-01","origin":"J1","destination":"J9"}'
curl -X POST http://PC_IP:8000/api/telemetry -H "Content-Type: application/json" -H "X-Vehicle-Key: demo-key-123" \
     -d '{"vehicle_id":"AMB-01","position_m":150,"speed_kmh":30}'
```
`position_m` = metres travelled along the planned route (map-match GPS or count RFID checkpoints).

## How the workflow maps to the code (`backend/engine.py`)
| Slide step | Code |
|---|---|
| Route optimisation (A*/Dijkstra) | `plan_route` - edge cost = travel time + delay score |
| Predictive corridor | `step()` - green starts at `ETA <= lead time`, lead grows with queue |
| Downstream-aware | lead time uses queue at the *next* junction too |
| Safety verification | junction box IR sensor -> alert when `ETA <= 6 s` and box not clear |
| Multi-vehicle priority | candidates sorted by `(priority, ETA)`, conflicts logged |
| GPS-spoof guard | implied speed vs reported speed in `telemetry()` |
| Recovery | `_schedule_recovery` - extra green to the heavier approach for 15 s |
| Fail-safe | command TTL + firmware falls back to normal cycle |

Tunable constants are at the top of `engine.py`. Demo-scale: 3x3 grid, 200 m blocks.
