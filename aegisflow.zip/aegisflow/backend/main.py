import os, json, time, threading, hashlib
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()
from fastapi import FastAPI, HTTPException, Header
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from engine import Engine
from db import DB

db = DB()
engine = Engine(sink=db.write)
NODE_KEY = os.getenv("NODE_KEY", "node-secret-123")
PREFIX = os.getenv("MQTT_PREFIX", "aegisflow-demo")
mqttc = None
_last_reading = {}

app = FastAPI(title="AegisFlow")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# ---------------- MQTT (optional) ----------------
def start_mqtt():
    global mqttc
    host = os.getenv("MQTT_HOST")
    if not host:
        print("[mqtt] disabled (HTTP-only mode)"); return
    import paho.mqtt.client as mqtt
    c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"aegisflow-backend-{os.getpid()}")
    if os.getenv("MQTT_USER"): c.username_pw_set(os.getenv("MQTT_USER"), os.getenv("MQTT_PASS"))

    def on_connect(cl, ud, flags, rc, props=None):
        print("[mqtt] connected", rc); cl.subscribe(f"{PREFIX}/junction/+/sensors")

    def on_message(cl, ud, msg):
        try:
            j = msg.topic.split("/")[2]; d = json.loads(msg.payload)
            ingest_sensors(j, d["q_ns"], d["q_ew"], d.get("box_clear", True))
        except Exception as e:
            print("[mqtt] bad message:", e)

    c.on_connect, c.on_message = on_connect, on_message
    c.connect_async(host, int(os.getenv("MQTT_PORT", 1883)), 30)
    c.loop_start(); mqttc = c


def publish(cmds):
    if not mqttc: return
    for cmd in cmds:
        mqttc.publish(f"{PREFIX}/junction/{cmd['junction']}/cmd", json.dumps(cmd), qos=0)


def ingest_sensors(j, q_ns, q_ew, box_clear):
    if not engine.update_sensors(j, q_ns, q_ew, box_clear): return
    if time.time() - _last_reading.get(j, 0) > 5:      # sample to DB every 5 s
        _last_reading[j] = time.time()
        db.write("sensor_readings", {"junction_id": j, "queue_ns": q_ns, "queue_ew": q_ew, "box_clear": box_clear})


def control_loop():
    while True:
        try: publish(engine.step())
        except Exception as e: print("[loop]", e)
        time.sleep(1)


@app.on_event("startup")
def startup():
    start_mqtt()
    threading.Thread(target=control_loop, daemon=True).start()


# ---------------- auth ----------------
def auth_vehicle(vid, key):
    v = db.get_vehicle(vid)
    if not v or hashlib.sha256((key or "").encode()).hexdigest() != v["api_key_hash"]:
        engine.event("AUTH_REJECTED", vid, None)
        raise HTTPException(401, "invalid vehicle credentials")
    return v


# ---------------- API ----------------
class Req(BaseModel):
    vehicle_id: str
    origin: str
    destination: str
    priority: int | None = None

class Tel(BaseModel):
    vehicle_id: str
    position_m: float
    speed_kmh: float

class Sens(BaseModel):
    junction: str
    q_ns: int
    q_ew: int
    box_clear: bool = True

class Done(BaseModel):
    vehicle_id: str
    travel_time_s: float | None = None
    stops: int | None = None


@app.post("/api/request")
def api_request(r: Req, x_vehicle_key: str = Header(None)):
    v = auth_vehicle(r.vehicle_id, x_vehicle_key)
    try:
        _, route = engine.request(r.vehicle_id, r.priority if r.priority is not None else v["priority"], r.origin, r.destination)
    except Exception as e:
        raise HTTPException(400, f"cannot plan route: {e}")
    return {"route": route}


@app.post("/api/telemetry")
def api_telemetry(t: Tel, x_vehicle_key: str = Header(None)):
    auth_vehicle(t.vehicle_id, x_vehicle_key)
    status = engine.telemetry(t.vehicle_id, t.position_m, t.speed_kmh)
    if status == "ok": publish(engine.step())
    return {"status": status}


@app.post("/api/sensors")
def api_sensors(s: Sens, x_node_key: str = Header(None)):
    if x_node_key != NODE_KEY: raise HTTPException(401, "bad node key")
    ingest_sensors(s.junction, s.q_ns, s.q_ew, s.box_clear)
    return {"ok": True}


@app.post("/api/complete")
def api_complete(d: Done, x_vehicle_key: str = Header(None)):
    auth_vehicle(d.vehicle_id, x_vehicle_key)
    return {"ok": engine.complete(d.vehicle_id, d.travel_time_s, d.stops)}


@app.get("/api/state")
def api_state(): return engine.snapshot()


DASH = Path(__file__).resolve().parent.parent / "dashboard" / "index.html"

@app.get("/")
def index(): return FileResponse(DASH)
