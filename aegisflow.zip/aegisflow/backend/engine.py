"""AegisFlow orchestration engine: route planning, predictive corridor,
safety verification, priority arbitration and recovery. No I/O inside."""
import time, threading, uuid
from collections import deque
from datetime import datetime, timezone
import networkx as nx

ROWS = COLS = 3
EDGE_M = 200            # distance between neighbouring junctions
START_OFFSET = 100      # vehicle starts this far before its first junction
FREE_KMH = 40
BASE_LEAD_S = 5         # safety margin before arrival
DISCHARGE_S = 1.8       # seconds to discharge one queued vehicle
ACTIVATE_MARGIN_S = 6   # extra window on top of the computed lead time
PASS_M = 15             # junction counts as passed this far behind us
RECOVERY_S = 15
CMD_TTL_S = 6           # ESP32 falls back to normal timing if no refresh
MAX_SPEED_KMH = 120     # plausibility limit (GPS-spoof guard)


def jid(r, c): return f"J{r * COLS + c + 1}"
def rc(j): return divmod(int(j[1:]) - 1, COLS)


def build_graph():
    G = nx.Graph()
    for r in range(ROWS):
        for c in range(COLS):
            G.add_node(jid(r, c))
            if c + 1 < COLS: G.add_edge(jid(r, c), jid(r, c + 1))
            if r + 1 < ROWS: G.add_edge(jid(r, c), jid(r + 1, c))
    return G


def axis(a, b):
    (r1, c1), (r2, c2) = rc(a), rc(b)
    return "NS" if c1 == c2 else "EW"


def route_approaches(route):
    if len(route) == 1: return ["NS"]
    return [axis(route[0], route[1])] + [axis(route[i - 1], route[i]) for i in range(1, len(route))]


def plan_route(origin, dest, score=lambda j: 0.0):
    """Dijkstra where each edge cost = free-flow time + predicted delay penalty."""
    def w(u, v, _): return EDGE_M / (FREE_KMH / 3.6) + 30.0 * score(v)
    return nx.shortest_path(build_graph(), origin, dest, weight=w)


def now_iso(): return datetime.now(timezone.utc).isoformat()


class Junction:
    def __init__(self, j):
        self.id, self.q = j, {"NS": 0, "EW": 0}
        self.box_clear, self.last_seen = True, 0.0
        self.mode, self.approach, self.expires = "NORMAL", None, 0.0


class Corridor:
    def __init__(self, vid, prio, route, req_id):
        self.vid, self.prio, self.route, self.req_id = vid, prio, route, req_id
        self.approach = route_approaches(route)
        self.position, self.speed_kmh = 0.0, 0.0
        self.last_t, self.passed, self.etas = None, set(), {}
        self.started, self.state = time.time(), "PREDICTION"

    def jpos(self, i): return START_OFFSET + i * EDGE_M


class Engine:
    def __init__(self, sink=None):
        self.lock = threading.RLock()
        self.sink = sink or (lambda table, row: None)
        self.junctions = {jid(r, c): Junction(jid(r, c)) for r in range(ROWS) for c in range(COLS)}
        self.active, self.recovery = {}, {}
        self.events, self.alerts = deque(maxlen=60), deque(maxlen=20)
        self._last_alert = {}

    # ---------- helpers ----------
    def event(self, etype, vid=None, j=None, **detail):
        row = {"vehicle_id": vid, "junction_id": j, "event_type": etype, "detail": detail}
        self.events.appendleft({**row, "at": now_iso()})
        self.sink("corridor_events", row)

    def alert(self, vid, j, msg):
        key = (vid, j, msg)
        if time.time() - self._last_alert.get(key, 0) < 10: return
        self._last_alert[key] = time.time()
        self.alerts.appendleft({"vehicle_id": vid, "junction": j, "msg": msg, "at": now_iso()})
        self.event("ALERT", vid, j, msg=msg)

    def score(self, j):
        """Emergency Delay Prediction Score 0..1 (queue + blockage)."""
        jn = self.junctions[j]
        return round(min(1.0, max(jn.q.values()) / 10) * 0.6 + (0 if jn.box_clear else 0.4), 2)

    # ---------- inputs ----------
    def update_sensors(self, j, q_ns, q_ew, box_clear):
        with self.lock:
            jn = self.junctions.get(j)
            if not jn: return False
            jn.q["NS"], jn.q["EW"] = int(q_ns), int(q_ew)
            jn.box_clear, jn.last_seen = bool(box_clear), time.time()
            return True

    def request(self, vid, prio, origin, dest):
        with self.lock:
            route = plan_route(origin, dest, self.score)
            req_id = str(uuid.uuid4())
            self.active[vid] = Corridor(vid, prio, route, req_id)
            self.event("CORRIDOR_PLANNED", vid, origin, route=route, priority=prio)
            self.sink("emergency_requests", {"id": req_id, "vehicle_id": vid, "origin": origin,
                      "destination": dest, "priority": prio, "route": route})
            return req_id, route

    def telemetry(self, vid, position_m, speed_kmh):
        with self.lock:
            c = self.active.get(vid)
            if not c: return "no_active_request"
            t = time.time()
            if c.last_t:
                dt = max(t - c.last_t, 0.05)
                implied = abs(position_m - c.position) / dt * 3.6
                if speed_kmh > MAX_SPEED_KMH or implied > MAX_SPEED_KMH * 1.2:
                    self.event("GPS_ANOMALY", vid, None, reported=speed_kmh, implied=round(implied, 1))
                    self.alert(vid, None, "Location anomaly - telemetry rejected")
                    return "anomaly"
            c.position, c.speed_kmh, c.last_t, c.state = position_m, speed_kmh, t, "PASSAGE"
            return "ok"

    def complete(self, vid, travel_time_s=None, stops=None):
        with self.lock:
            c = self.active.pop(vid, None)
            if not c: return False
            self.event("CORRIDOR_COMPLETE", vid, None, travel_time_s=travel_time_s, stops=stops)
            self.sink("__update__emergency_requests", {"id": c.req_id, "status": "completed",
                      "travel_time_s": travel_time_s, "stops": stops})
            return True

    # ---------- the brain ----------
    def step(self, now=None):
        now = now or time.time()
        out, wants = [], {}
        with self.lock:
            for c in list(self.active.values()):
                v = max(c.speed_kmh / 3.6, 3.0)
                for i, j in enumerate(c.route):
                    if j in c.passed: continue
                    dist = c.jpos(i) - c.position
                    if dist < -PASS_M:
                        c.passed.add(j); c.state = "RECOVERY"
                        self._schedule_recovery(j, now)
                        self.event("JUNCTION_PASSED", c.vid, j)
                        continue
                    eta = dist / v
                    c.etas[j] = round(eta, 1)
                    q_here = self.junctions[j].q[c.approach[i]]
                    q_next = 0
                    if i + 1 < len(c.route):          # downstream-aware lead time
                        q_next = self.junctions[c.route[i + 1]].q[c.approach[i + 1]]
                    lead = BASE_LEAD_S + DISCHARGE_S * max(q_here, q_next)
                    if eta <= lead + ACTIVATE_MARGIN_S:
                        blocked = eta <= 6 and not self.junctions[j].box_clear
                        if blocked: self.alert(c.vid, j, "Junction box NOT clear - extend clearance")
                        wants.setdefault(j, []).append((c.prio, eta, c.vid, c.approach[i], blocked))
                if len(c.passed) == len(c.route):
                    self.active.pop(c.vid, None)
                    self.event("CORRIDOR_COMPLETE", c.vid, None, auto=True)
                    self.sink("__update__emergency_requests", {"id": c.req_id, "status": "completed"})

            for j, jn in self.junctions.items():
                cmd = None
                if j in wants:
                    prio, eta, vid, appr, _ = sorted(wants[j])[0]
                    cand = wants[j]
                    if len({x[3] for x in cand}) > 1:
                        self.event("CORRIDOR_CONFLICT", vid, j, winner=vid, others=[x[2] for x in cand if x[2] != vid])
                    cmd = {"junction": j, "mode": "EMERGENCY", "approach": appr, "ttl_s": CMD_TTL_S,
                           "vehicle": vid, "priority": prio, "alert": any(x[4] for x in cand)}
                elif j in self.recovery and self.recovery[j][1] > now:
                    appr, until = self.recovery[j]
                    cmd = {"junction": j, "mode": "RECOVERY", "approach": appr,
                           "ttl_s": max(1, min(CMD_TTL_S, int(until - now))), "alert": False}
                else:
                    self.recovery.pop(j, None)
                    if jn.mode != "NORMAL":
                        cmd = {"junction": j, "mode": "NORMAL", "ttl_s": 0, "alert": False}
                if cmd:
                    if cmd["mode"] != jn.mode:
                        self.event("MODE_" + cmd["mode"], cmd.get("vehicle"), j, approach=cmd.get("approach"))
                        self.sink("signal_commands", {"junction_id": j, "mode": cmd["mode"], "approach": cmd.get("approach"),
                                                      "vehicle_id": cmd.get("vehicle"), "ttl_s": cmd["ttl_s"]})
                    jn.mode, jn.approach = cmd["mode"], cmd.get("approach")
                    jn.expires = now + cmd["ttl_s"]
                    out.append(cmd)
        return out

    def _schedule_recovery(self, j, now):
        q = self.junctions[j].q
        if max(q.values()) >= 3:
            self.recovery[j] = ("NS" if q["NS"] >= q["EW"] else "EW", now + RECOVERY_S)

    # ---------- view ----------
    def snapshot(self):
        now = time.time()
        with self.lock:
            return {
                "t": now,
                "junctions": {j: {"q_ns": jn.q["NS"], "q_ew": jn.q["EW"], "box_clear": jn.box_clear,
                                  "mode": jn.mode, "approach": jn.approach, "score": self.score(j),
                                  "online": now - jn.last_seen < 5,
                                  "expires_in": round(max(0, jn.expires - now), 1)}
                              for j, jn in self.junctions.items()},
                "corridors": [{"vehicle_id": c.vid, "priority": c.prio, "route": c.route, "state": c.state,
                               "position_m": round(c.position, 1), "speed_kmh": round(c.speed_kmh, 1),
                               "etas": c.etas, "passed": sorted(c.passed)} for c in self.active.values()],
                "alerts": list(self.alerts)[:8], "events": list(self.events)[:15],
            }
