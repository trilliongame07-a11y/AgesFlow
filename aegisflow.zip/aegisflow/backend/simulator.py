"""Software-only demo: virtual junctions + virtual ambulance (no hardware needed).
  python simulator.py                 -> AegisFlow ON  (registers corridor)
  python simulator.py --baseline      -> plain fixed-time signals, for comparison
  python simulator.py --block J6      -> junction J6 box blocked as the ambulance approaches (safety demo)
"""
import argparse, os, random, time, requests
from dotenv import load_dotenv
from engine import plan_route, route_approaches, START_OFFSET, EDGE_M

load_dotenv()
ap = argparse.ArgumentParser()
ap.add_argument("--api", default="http://127.0.0.1:8000")
ap.add_argument("--origin", default="J1"); ap.add_argument("--dest", default="J9")
ap.add_argument("--baseline", action="store_true"); ap.add_argument("--block", default="")
ap.add_argument("--vehicle", default="AMB-01"); ap.add_argument("--key", default="demo-key-123")
a = ap.parse_args()
VH = {"X-Vehicle-Key": a.key}; NH = {"X-Node-Key": os.getenv("NODE_KEY", "node-secret-123")}
J = [f"J{i}" for i in range(1, 10)]
queues = {j: [random.randint(2, 8), random.randint(2, 8)] for j in J}


def push_sensors(t):
    for j in J:
        for k in (0, 1): queues[j][k] = max(0, min(10, queues[j][k] + random.choice([-1, 0, 0, 1])))
        clear = not (j == a.block and j in route and 0 < jpos[route.index(j)] - pos < 70)
        requests.post(f"{a.api}/api/sensors", headers=NH, timeout=2,
                      json={"junction": j, "q_ns": queues[j][0], "q_ew": queues[j][1], "box_clear": clear})


def green(cmds, j, appr, t):
    c = cmds.get(j, {})
    if c.get("mode") in ("EMERGENCY", "RECOVERY") and c.get("expires_in", 0) > 0:
        return c["approach"] == appr
    return (int(t // 10) % 2 == 0) == (appr == "NS")      # normal fixed-time cycle


if a.baseline: route = plan_route(a.origin, a.dest)
else:
    r = requests.post(f"{a.api}/api/request", headers=VH, timeout=3,
                      json={"vehicle_id": a.vehicle, "origin": a.origin, "destination": a.dest}); r.raise_for_status()
    route = r.json()["route"]
appr = route_approaches(route)
jpos = [START_OFFSET + i * EDGE_M for i in range(len(route))]
print("Route:", " -> ".join(route), "| mode:", "BASELINE" if a.baseline else "AEGISFLOW")

pos, speed, stops, stopped, t0, last_push, cmds = 0.0, 0.0, 0, False, time.time(), -9, {}
while pos < jpos[-1] + 20:
    t = time.time() - t0
    if t - last_push >= 1:
        push_sensors(t); last_push = t
        if not a.baseline:
            st = requests.get(f"{a.api}/api/state", timeout=2).json()
            cmds = {j: {"mode": v["mode"], "approach": v["approach"], "expires_in": v["expires_in"]} for j, v in st["junctions"].items()}
    must_stop = False
    for i, jp in enumerate(jpos):
        d = jp - pos
        if 0 < d <= 20 and not green(cmds, route[i], appr[i], t): must_stop = True
    if must_stop:
        speed = 0.0
        if not stopped: stops += 1; stopped = True
    else:
        speed = min(40.0, speed + 8.0 * 0.5); stopped = False
    pos += speed / 3.6 * 0.5
    if not a.baseline:
        requests.post(f"{a.api}/api/telemetry", headers=VH, timeout=2,
                      json={"vehicle_id": a.vehicle, "position_m": pos, "speed_kmh": speed})
    print(f"\rt={t:5.1f}s pos={pos:6.1f}m speed={speed:4.1f}km/h stops={stops}   ", end="", flush=True)
    time.sleep(0.5)
tt = time.time() - t0
print(f"\nTRAVEL TIME: {tt:.1f}s | STOPS: {stops} | mode: {'BASELINE' if a.baseline else 'AEGISFLOW'}")
if not a.baseline:
    requests.post(f"{a.api}/api/complete", headers=VH, json={"vehicle_id": a.vehicle, "travel_time_s": round(tt, 1), "stops": stops})
