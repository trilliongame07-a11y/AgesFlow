"""Supabase wrapper. Writes go through a background queue so the control loop
never blocks on the network. If Supabase is not configured, everything still runs."""
import os, queue, threading, hashlib


class DB:
    def __init__(self):
        self.client, self.q = None, queue.Queue(maxsize=2000)
        url, key = os.getenv("SUPABASE_URL"), os.getenv("SUPABASE_SERVICE_KEY")
        self.demo = {}
        for item in filter(None, os.getenv("DEMO_VEHICLES", "").split(",")):
            vid, k, pr = (item.split(":") + ["1"])[:3]
            self.demo[vid] = {"id": vid, "priority": int(pr), "active": True,
                              "api_key_hash": hashlib.sha256(k.encode()).hexdigest()}
        if url and key and "YOUR-PROJECT" not in url:
            try:
                from supabase import create_client
                self.client = create_client(url, key)
                threading.Thread(target=self._worker, daemon=True).start()
                print("[db] Supabase connected")
            except Exception as e:
                print("[db] Supabase disabled:", e)
        else:
            print("[db] Supabase not configured -> offline mode")

    def _worker(self):
        while True:
            fn = self.q.get()
            try: fn()
            except Exception as e: print("[db] write failed:", e)

    def write(self, table, row):
        if not self.client: return
        if table.startswith("__update__"):
            t = table.replace("__update__", "")
            rid = row.pop("id")
            fn = lambda: self.client.table(t).update({k: v for k, v in row.items() if v is not None}).eq("id", rid).execute()
        else:
            fn = lambda: self.client.table(table).insert(row).execute()
        try: self.q.put_nowait(fn)
        except queue.Full: pass

    def get_vehicle(self, vid):
        if self.client:
            try:
                r = self.client.table("vehicles").select("*").eq("id", vid).eq("active", True).limit(1).execute()
                return r.data[0] if r.data else None
            except Exception as e:
                print("[db] vehicle lookup failed:", e)
        return self.demo.get(vid)
