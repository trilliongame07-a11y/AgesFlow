-- AegisFlow schema. Paste into Supabase Dashboard > SQL Editor > Run.
create extension if not exists pgcrypto;

create table if not exists public.junctions (
  id text primary key, name text, row_idx int, col_idx int, created_at timestamptz default now());

create table if not exists public.vehicles (
  id text primary key,
  type text default 'ambulance',
  priority smallint default 1 check (priority between 0 and 3),  -- P0 catastrophic .. P3 routine
  api_key_hash text not null,                                     -- sha256 of the vehicle key
  active boolean default true,
  created_at timestamptz default now());

create table if not exists public.emergency_requests (
  id uuid primary key default gen_random_uuid(),
  vehicle_id text references public.vehicles(id),
  origin text, destination text, priority smallint, route jsonb,
  status text default 'active',
  started_at timestamptz default now(), completed_at timestamptz,
  travel_time_s numeric, stops int);

create table if not exists public.sensor_readings (
  id bigint generated always as identity primary key,
  junction_id text references public.junctions(id),
  queue_ns smallint, queue_ew smallint, box_clear boolean,
  recorded_at timestamptz default now());
create index if not exists sensor_readings_j_t on public.sensor_readings (junction_id, recorded_at desc);

create table if not exists public.signal_commands (
  id bigint generated always as identity primary key,
  junction_id text references public.junctions(id),
  mode text, approach text, vehicle_id text, ttl_s int,
  created_at timestamptz default now());

create table if not exists public.corridor_events (
  id bigint generated always as identity primary key,
  vehicle_id text, junction_id text, event_type text, detail jsonb,
  created_at timestamptz default now());
create index if not exists corridor_events_t on public.corridor_events (created_at desc);

-- completed-run KPIs for the evaluation slide
create or replace view public.corridor_kpis as
select count(*) filter (where status='completed') as runs,
       round(avg(travel_time_s),1) as avg_travel_time_s,
       round(avg(stops),2) as avg_stops
from public.emergency_requests;

-- Row Level Security: backend uses the service-role key (bypasses RLS).
-- The anon key (browser) gets read-only access to non-sensitive tables.
alter table public.junctions enable row level security;
alter table public.vehicles enable row level security;          -- no policy => hidden from anon
alter table public.emergency_requests enable row level security;
alter table public.sensor_readings enable row level security;
alter table public.signal_commands enable row level security;
alter table public.corridor_events enable row level security;

create policy "anon read junctions" on public.junctions for select to anon using (true);
create policy "anon read requests" on public.emergency_requests for select to anon using (true);
create policy "anon read readings" on public.sensor_readings for select to anon using (true);
create policy "anon read commands" on public.signal_commands for select to anon using (true);
create policy "anon read events" on public.corridor_events for select to anon using (true);

-- Realtime (optional live dashboard via supabase-js)
alter publication supabase_realtime add table public.corridor_events, public.emergency_requests;

-- Seed data
insert into public.junctions (id, name, row_idx, col_idx)
select 'J'||(r*3+c+1), 'Junction '||(r*3+c+1), r, c from generate_series(0,2) r, generate_series(0,2) c
on conflict do nothing;

-- demo vehicle: AMB-01, key "demo-key-123"  (change before any real use!)
insert into public.vehicles (id, priority, api_key_hash)
values ('AMB-01', 1, 'a52782e3a2d4dd2f95f640b9abfb3b2a6b8e722c65f55be830f6e5f619f7f873')
on conflict do nothing;
